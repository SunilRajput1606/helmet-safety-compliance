# ============================================================
#  tracker.py
#  ByteTrack — har worker ko unique ID deta hai
# ============================================================

from ultralytics import YOLO
import numpy as np


class Tracker:
    """
    ByteTrack wrapper.
    Sirf Person class track karta hai.
    Har worker ko consistent ID deta hai across frames.
    """

    def __init__(self, model_path: str = "yolov8n.pt",
                 conf: float = 0.30, iou: float = 0.30):
        print(f"[Tracker] ByteTrack ready!")
        try:
            self.model = YOLO(model_path)
        except Exception as e:
            raise RuntimeError(f"[Tracker] Fail: {e}")

        self.conf = conf
        self.iou  = iou

    # ----------------------------------------------------------
    def track(self, frame: np.ndarray) -> list[dict]:
        """
        Frame mein persons track karo.

        Returns:
        [
          {
            "track_id"  : 3,
            "box"       : [x1, y1, x2, y2],
            "class_name": "Person",
            "conf"      : 0.87,
            "cx"        : 150,
            "cy"        : 230,
            "head_box"  : [x1, y1, x2, y1+h*0.35]  ← sir ka area
          }
        ]
        """
        results = self.model.track(
            frame,
            persist = True,
            tracker = "bytetrack.yaml",
            conf    = self.conf,
            iou     = self.iou,
            verbose = False,
        )

        tracked = []
        r = results[0]

        if r.boxes.id is None:
            return tracked

        for box, tid, cls_id, conf in zip(
            r.boxes.xyxy.cpu().numpy(),
            r.boxes.id.cpu().numpy().astype(int),
            r.boxes.cls.cpu().numpy().astype(int),
            r.boxes.conf.cpu().numpy(),
        ):
            # Sirf person
            if int(cls_id) != 0:
                continue

            x1, y1, x2, y2 = box
            cx = int((x1 + x2) / 2)
            cy = int((y1 + y2) / 2)
            h  = y2 - y1

            # Sir ka area = upar ka 35% hissa
            # Yahan helmet check hoga
            head_box = [
                float(x1), float(y1),
                float(x2), float(y1 + h * 0.35)
            ]

            tracked.append({
                "track_id"  : int(tid),
                "box"       : [float(x1), float(y1),
                               float(x2), float(y2)],
                "class_name": "Person",
                "conf"      : float(conf),
                "cx"        : cx,
                "cy"        : cy,
                "head_box"  : head_box,
            })

        return tracked
